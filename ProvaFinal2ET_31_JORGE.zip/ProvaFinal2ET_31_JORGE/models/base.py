# ModeloBase — campos comuns herdados por ColetaNoticia e Noticia.

from datetime import datetime

from . import db


class ModeloBase(db.Model):
    """Classe abstrata com id, data_criacao e data_atualizacao."""
    __abstract__ = True
 

    id = db.Column(db.Integer,primary_key=True)
    data_criacao = db.Column(db.DateTime, default=datetime.now, nullable=False)
    data_atualizacao = db.Column(
        db.DateTime,
        default=datetime.now,
        onupdate=datetime.now,
        nullable=False,
    )
